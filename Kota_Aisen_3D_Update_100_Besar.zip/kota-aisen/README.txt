KOTA AISEN 3D — UPDATE BESAR 100+
Cara main:
1. Ekstrak ZIP.
2. Buka kota-aisen/index.html di browser modern.
3. Koneksi internet diperlukan untuk memuat Three.js dari CDN.

Update:
- 100 dekorasi kota 3D baru (bangku, lampu jalan, taman bunga, papan informasi).
- Bonus harian +300 koin.
- Tantangan harian bekerja, mengunjungi tempat, dan mini game.
- Sistem pencapaian dan progres yang disimpan di browser.
- Perbaikan ID elemen antarmuka yang bentrok.
Catatan: mode solo; progres disimpan di browser perangkat ini.
